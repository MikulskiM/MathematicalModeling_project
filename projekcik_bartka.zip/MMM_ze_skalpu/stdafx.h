// stdafx.h: do��cz plik do standardowych systemowych plik�w do��czanych,
// lub specyficzne dla projektu pliki do��czane, kt�re s� cz�sto wykorzystywane, ale
// s� rzadko zmieniane
//



#define PI 3.14159265

//#include <windows.h>
#include <stdio.h>
//#include <tchar.h>
#include <cmath>
#include <math.h>
#include <iostream>
#include <queue>

#include "tmat.h"       // biblioteki do obslugi macierzy
#include "tvec.h"



